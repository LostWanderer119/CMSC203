public class Clerk extends Person {
    private String job;

    public Clerk(String name, int age, int yearsWorked, String job) {
        super(name, age, yearsWorked);
        this.job = job;
    }
    
   public Clerk (Clerk obj) {
	   super(obj.getName(), obj.getAge(), obj.getYearsWorked());
	   this.job = obj.getJob();
   }


    public String getJob() {
        return job;
    }

    
    @Override
    public String toString() {
    	return ("Name: " + getName() + "\nAge: " + getAge() + "\nYears Worked: " + getYearsWorked() + "\nJob: " + job);      
    }   
     
}
