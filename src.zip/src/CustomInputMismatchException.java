import java.util.InputMismatchException;

//Custom exception class for input mismatches
public class CustomInputMismatchException extends InputMismatchException {
	private static final long serialVersionUID = 1L;

	public CustomInputMismatchException () {
		super("Invalid input type. Please enter a valid integer.");
	}

	public CustomInputMismatchException (String message) {
		super(message);
	}
}
