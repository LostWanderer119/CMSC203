import java.util.ArrayList;
import java.util.List;

public class Circus {
    private List<Animal> animals;
    private List<Person> persons;
    private List<Building> buildings;
    private List<Ticket> tickets;

    public Circus() {
        animals = new ArrayList<>();
        persons = new ArrayList<>();
        buildings = new ArrayList<>();
        tickets = new ArrayList<>();
    }
    
    public void sortAnimalsByAge () {
    	int length = animals.size();
    	for (int i = 0; i < length - 1; i++) {
    		int minIndex = i;
    		int minAge = animals.get(i).getAge();
    		for (int index = i + 1; index < length; index++) {
    			if (animals.get(index).getAge() < minAge) {
    				minAge = animals.get(index).getAge();
    				minIndex = index;
    			}
    		}		
    		if (minIndex != i) {
    			Animal temp = animals.get(minIndex);
                animals.set(minIndex, animals.get(i));
                animals.set(i, temp);
    		}
    	}
    }


    public void sortAnimalsByName () {
    	int length = animals.size();
    	for (int i = 0; i < length - 1; i++) {
    		int minIndex = i;
    		String minName = animals.get(i).getName();
    		for (int index = i + 1; index < length; index++) {
    			if (animals.get(index).getName().compareToIgnoreCase(minName) < 0) {
    				minName = animals.get(index).getName();
    				minIndex = index;
    			}
    		}		
    		if (minIndex != i) {
    			Animal temp = animals.get(minIndex);
                animals.set(minIndex, animals.get(i));
                animals.set(i, temp);
    		}
    	}
    }
 
    
    public int searchAnimalByName (String name) { // binary search
    	sortAnimalsByName ();
    	int first = 0, last = animals.size() - 1, middle;
    	while (first <= last) {
    		middle = (first + last)/2;
    		String middleName = animals.get(middle).getName();
            int comparison = middleName.compareToIgnoreCase(name);
            
    		if (comparison == 0) {
    			return middle;
    		} else if (comparison < 0) {
    			first = middle + 1;
    		} else {
    			last = middle - 1;
    		}
    	}
    	return -1;
    }
    
    public void displayAllAnimals () {
    	for (int i = 0; i < animals.size(); i++) {
    	    System.out.print(animals.get(i));
    	    if (i < animals.size() - 1) System.out.print(", ");
    	    System.out.println();
    	}
    	System.out.println();
    }
    
    public void displayAllBuildings () {
    	for (int i = 0; i < buildings.size(); i++) {
    	    System.out.print(buildings.get(i));
    	    if (i < animals.size() - 1) System.out.print(", ");
    	    System.out.println();
    	}
    }
    
    public void displayAllPersons () {
    	for (int i = 0; i < persons.size(); i++) {
    	    System.out.print(persons.get(i));
    	    if (i < animals.size() - 1) System.out.print(", ");
    	    System.out.println();
    	}
    }
    
    public void addPerson (Person person) {persons.add(person);}
    
    public void addBuilding (Building building) {buildings.add(building);}
    
    public void addAnimal (Animal animal) {animals.add(animal);}
    
    public void addTicket (Ticket ticket) {tickets.add(ticket);}
    
    public List<Person> getPerson () {return persons;}
    
    public List<Building> getBuildings () {return buildings;}
    
    public List<Animal> getAnimals () {return animals;}
    
    public List<Ticket> getTickets () {return tickets;}

    public Ticket generateTicket(String dayOfWeek, double basePrice, int age) {
        Ticket ticket = new Ticket(dayOfWeek, basePrice, age);  // Pass dayOfWeek, basePrice, age to Ticket constructor
        addTicket(ticket);
        return ticket;
    }
}
