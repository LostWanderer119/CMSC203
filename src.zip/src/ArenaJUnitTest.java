import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArenaJUnitTest {

    private Arena arena;

    @BeforeEach
    void setUp() {
        arena = new Arena("Blue", 100.0, 50.0);
    }

    @Test
    void testConstructorAndInitialValues() {
        assertEquals("Blue", arena.getColor(), "Initial color is incorrect.");
        assertEquals(100.0, arena.getLength(), 0.001, "Initial length is incorrect.");
        assertEquals(50.0, arena.getWidth(), 0.001, "Initial width is incorrect.");
        assertEquals("Arena", arena.getBuildingType(), "Initial building type is incorrect.");
    }

    @Test
    public void testSetSize() {
    	arena.setSize(1.2, 1.3);
    	assertEquals(1.2, arena.getLength(), 0.001);
    	assertEquals(1.3, arena.getWidth(), 0.001);
    }
	
	@Test
	public void testSetColor() {
		arena.setColor("Blue");
		assertEquals("Blue", arena.getColor());
	}


    @Test
	public void testSetBuildingType() {
    	arena.setBuildingType("Prison");
    	assertEquals("Prison", arena.getBuildingType());
    }

      
    @Test
	public void testToString() {
    	assertEquals("Length: 100.0, Width: 50.0, Color: Blue, Building Type: Arena" , arena.toString());
    }  
}
