

public class Bird implements Animal {
	//instance variables
    private String name;
    private int age;
    private String species;
    private String color;

    //constructor
    public Bird(String name, int age, String species, String color) {
        this.name = name;
        this.age = age;
        this.species = species;
        this.color = color;
    }

    public Bird (Bird obj) {
    	this.name = obj.getName ();
    	this.age = obj.getAge();
    	this.species = obj.getSpecies();
    	this.color = obj.getColor();
    }

    @Override
    public void move() {
    	System.out.print("Walk/Fly");
    }

    @Override
    public void makeSound() {
    	System.out.print("Chirp Chirp");
    }

    @Override
    public String getName() {return name;}

    @Override
    public int getAge() {return age;}

    public String getSpecies() {return species;}

    public String getColor() {return color;}

    public Boolean equals (Bird obj) {
    	if (name == obj.getName() && age == obj.getAge() && species == obj.getSpecies() && color == obj.getColor()) {return true;} 
    	return false;
    }

    @Override
    public String toString () {return ("Name: " + name + ", Age: " + age + ", Species: " + species + ", Color: " + color);}
  
}
