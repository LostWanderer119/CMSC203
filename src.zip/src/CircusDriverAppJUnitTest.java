import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class CircusDriverAppJUnitTest {
    private Circus circus;

    @BeforeEach
    void setUp() {
        circus = new Circus();
    }

    @Test
    void testAddDog() {
        Dog dog = new Dog("Shila", 3, "Golden Retriever", "Brown");
        circus.addAnimal(dog);
        List<Animal> animals = circus.getAnimals();
        assertEquals(1, animals.size());
        assertTrue(animals.get(0) instanceof Dog);
        assertEquals("Shila", animals.get(0).getName());
    }

    @Test
    void testAddBird() {
        Bird bird = new Bird("Sky", 2, "Parrot", "Green");
        circus.addAnimal(bird);

        List<Animal> animals = circus.getAnimals();
        assertEquals(1, animals.size());
        assertTrue(animals.get(0) instanceof Bird);
        assertEquals("Sky", animals.get(0).getName());
    }

    @Test
    void testDisplayAnimals() {
        circus.addAnimal(new Dog("Max", 4, "Husky", "Gray"));
        circus.addAnimal(new Bird("Kiwi", 1, "Parakeet", "Yellow"));

        assertDoesNotThrow(() -> circus.displayAllAnimals());
    }
    
    @Test
    void testSortAnimalsByAge() {
        circus.addAnimal(new Dog("A", 5, "Breed", "Color"));
        circus.addAnimal(new Dog("B", 2, "Breed", "Color"));
        circus.addAnimal(new Dog("C", 7, "Breed", "Color"));

        circus.sortAnimalsByAge();
        List<Animal> animals = circus.getAnimals();

        assertEquals("B", animals.get(0).getName());
        assertEquals("A", animals.get(1).getName());
        assertEquals("C", animals.get(2).getName());
    }

    @Test
    void testSortAnimalsByName() {
        circus.addAnimal(new Dog("Charlie", 3, "Breed", "Color"));
        circus.addAnimal(new Dog("Bella", 2, "Breed", "Color"));
        circus.addAnimal(new Dog("Alex", 5, "Breed", "Color"));

        circus.sortAnimalsByName();
        List<Animal> animals = circus.getAnimals();

        assertEquals("Alex", animals.get(0).getName());
        assertEquals("Bella", animals.get(1).getName());
        assertEquals("Charlie", animals.get(2).getName());
    }

    @Test
    void testSearchAnimalByName() {
        circus.addAnimal(new Dog("Luna", 4, "Breed", "Color"));
        circus.addAnimal(new Dog("Milo", 2, "Breed", "Color"));
        circus.sortAnimalsByName();

        int index = circus.searchAnimalByName("Milo");
        assertEquals(1, index);

        int notFound = circus.searchAnimalByName("Ghost");
        assertEquals(-1, notFound);
    }

    @Test
    void testAddAndDisplayTickets() {
        Ticket ticket = circus.generateTicket("Monday", 20.0, 25);

        assertNotNull(ticket);
        assertEquals("monday", ticket.getDayOfWeek());
        assertEquals(20.0, ticket.getBasePrice());
        assertEquals(25, ticket.getAge());

        List<Ticket> tickets = circus.getTickets();
        assertEquals(1, tickets.size());
        assertEquals(ticket, tickets.get(0));
    }
}



