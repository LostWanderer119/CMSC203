

public class Lion implements Animal {
	//instance variables
    private String name;
    private int age;
    private String species;
    private String color;

    //constructor
    public Lion(String name, int age, String species, String color) {
        this.name = name;
        this.age = age;
        this.species = species;
        this.color = color;
    }
   	
    public Lion (Lion obj) {
    	this.name = obj.getName ();
    	this.age = obj.getAge();
    	this.species = obj.getSpecies();
    	this.color = obj.getColor();
    }

    @Override
    public void move() {
    	System.out.print("Walk/Run");
    }

    @Override
    public void makeSound() {
    	System.out.print("Roar");
    }

    @Override
    public String getName() {return name;}

    @Override
    public int getAge() {return age;}

    public String getSpecies() {return species;}

    public String getColor() {return color;}

    public Boolean equals (Lion obj) {
    	if (name == obj.getName() && age == obj.getAge() && species == obj.getSpecies() && color == obj.getColor()) {return true;} 
    	return false;
    }

    @Override
    public String toString () {return ("Name: " + name + ", Age: " + age + ", Species: " + species + ", Color: " + color);}

}
