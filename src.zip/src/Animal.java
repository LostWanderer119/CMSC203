public interface Animal {
    void move();
    void makeSound();

    String getName();
    int getAge();
}
