public class Ticket {
    private double basePrice;
    private String dayOfWeek;
    private int age;

    public Ticket(String dayOfWeek, double basePrice, int age) {
        this.basePrice = basePrice;
        this.age = age;
        this.dayOfWeek = dayOfWeek.toLowerCase();
    }

    // Calculate ticket price based on day of week and age
        // Apply discounts for weekdays
        // Apply age-based discounts
    public Ticket (Ticket obj) {
    	this.basePrice = obj.getBasePrice();
    	this.age = obj.getAge();
    	this.dayOfWeek = obj.getDayOfWeek().toLowerCase();
    }
    
    public double getBasePrice () {return basePrice;}
    
    public int getAge () {return age;}
    
    public String getDayOfWeek () {return dayOfWeek;}

    public double calculatePrice (String day, int age) {
    	double ticketPrice = basePrice;
    	if (dayOfWeek.equals("monday") || dayOfWeek.equals("tuesday") || dayOfWeek.equals("wednesday") || dayOfWeek.equals("thursday") || dayOfWeek.equals("friday")) {
    		ticketPrice *= .9;
    	}
    	if (age >= 0 && age <= 17) { //child & student
    		ticketPrice *= .9;
    	} else if (age >= 65 ) { //senior
    		ticketPrice *= .95;
    	}
    	return ticketPrice;
    }

    // Display the ticket details
    public void displayTicketDetails() {
        System.out.printf("Ticket Details: [Age: %d, Day: %s, Price: $%.2f]%n",
                          age, dayOfWeek.substring(0, 1).toUpperCase() + dayOfWeek.substring(1), calculatePrice(dayOfWeek, age));
    }

    @Override
    public String toString() {
        return String.format("Ticket [Day: %s, Age: %d, Price: $%.2f]",
                             dayOfWeek.substring(0, 1).toUpperCase() + dayOfWeek.substring(1), 
                             age, calculatePrice(dayOfWeek, age));
    }
}
