import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TicketingOfficeJUnitTest {

    private TicketingOffice office;

	@BeforeEach
	void setUp() throws Exception {
	   	office = new TicketingOffice("Grey", 14.5, 17.6);
	}

    @Test
    public void testConstructor() {
    	assertEquals("Grey", office.getColor());
    	assertEquals(14.5, office.getLength(), 0.001);
    	assertEquals(17.6, office.getWidth(), 0.001);
    	assertEquals("Ticketing Office", office.getBuildingType());
    }
	
    @Test
    public void testSetSize() {
    	office.setSize(1.2, 1.3);
    	assertEquals(1.2, office.getLength(), 0.001);
    	assertEquals(1.3, office.getWidth(), 0.001);
    }
	
	@Test
	public void testSetColor() {
		office.setColor("Blue");
		assertEquals("Blue", office.getColor());
	}


    @Test
	public void testSetBuildingType() {
    	office.setBuildingType("Prison");
    	assertEquals("Prison", office.getBuildingType());
    }

      
    @Test
	public void testToString() {
    	assertEquals("Length: 14.5, Width: 17.6, Color: Grey, Building Type: Ticketing Office" , office.toString());
    }  
}
