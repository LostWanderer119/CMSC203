public class Acrobatic extends Person {
    private String job;

    public Acrobatic(String name, int age, int yearsWorked, String job) {
        super(name, age, yearsWorked);
        this.job = job;
    }
    
   public Acrobatic (Acrobatic obj) {
	   super(obj.getName(), obj.getAge(), obj.getYearsWorked());
	   this.job = obj.getJob();
   }


    public String getJob() {
        return job;
    }

    
    @Override
    public String toString() {
    	return ("Name: " + getName() + "\nAge: " + getAge() + "\nYears Worked: " + getYearsWorked() + "\nJob: " + job);   
    }   
  
}
