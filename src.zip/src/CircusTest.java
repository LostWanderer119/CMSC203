import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CircusTest {
	
	private Circus circus;

	@BeforeEach
	void setUp() throws Exception {
		circus = new Circus();
		circus.addAnimal(new Lion("Simba", 6, "Panthera leo", "Golden"));
		circus.addAnimal(new Dog("Buddy", 5, "Labrador", "Brown"));
		circus.addAnimal(new Bird("Tweety", 2, "Canary", "Yellow"));
		circus.addAnimal(new Horse("Spirit", 4, "Mustang", "Brown"));
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testSortAnimalByName () { //pass
		System.out.print("\nSort by name\n");
		circus.displayAllAnimals();
		circus.sortAnimalsByName();
		System.out.print("\n\n");
		circus.displayAllAnimals();
	}
	
	@Test
	void testSortAnimalByAge () { //pass
		System.out.print("\nSort by age\n");
		circus.displayAllAnimals();
		circus.sortAnimalsByAge();
		System.out.print("\n\n");
		circus.displayAllAnimals();
	}
	
	@Test
	void testSearchAnimalByName () {
		System.out.print("\n\nSearching\n\n");
		circus.sortAnimalsByName();
		circus.displayAllAnimals();
		assertEquals(3, circus.searchAnimalByName("Tweety"));
	}

}
